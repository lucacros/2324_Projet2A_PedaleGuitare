/*
 * conversion.c
 *
 *  Created on: Mar 5, 2024
 *      Author: Luca
 */


#include "conversion.h"

float conversion1(int16_t value) {

    return (((float)value - (-20000.0f)) / (20000.0f - (-20000.0f))) * (1.0f - (-1.0f)) + (-1.0f);

}

int16_t conversion2(float value) {
		float tmp = ((value - (-1.0f)) / (1.0f - (-1.0f))) * (20000.0f - (-20000.0f)) + (-20000.0f);
    return ((int16_t)tmp);

}
