#include "distorsion.h"

//distorsion effect
void distorsion(int16_t*signal, int signalsize, float gaind){

	float maxsignal = 3500;

	for(int i=0; i < signalsize; i++){

		float tmp = gaind * (float)(signal[i]);

		if(tmp > maxsignal)
			{
				signal[i]= (int16_t)maxsignal;
			}
		else if(tmp <-maxsignal)
			{
				signal[i]=(int16_t)(-maxsignal);
			}

		else
			{
				signal[i]= (int16_t)(tmp);
			}


	}
}

