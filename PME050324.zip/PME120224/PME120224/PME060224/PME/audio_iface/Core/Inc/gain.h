/*
 * gain.h
 *
 *  Created on: Feb 6, 2024
 *      Author: Luca
 */


#include <stdlib.h>
#include <stdint.h>

void gain(int16_t*signal, int signalsize, float gain);
