/*
 * conversion.h
 *
 *  Created on: Mar 5, 2024
 *      Author: Luca
 */

#ifndef INC_CONVERSION_H_
#define INC_CONVERSION_H_
#include <stdint.h>

float conversion1(int16_t value);
int16_t conversion2(float value);

#endif /* INC_CONVERSION_H_ */
