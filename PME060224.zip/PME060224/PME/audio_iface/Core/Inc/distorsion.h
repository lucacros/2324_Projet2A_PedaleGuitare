/*
 * distorsion.h
 *
 *  Created on: Jan 16, 2024
 *      Author: Luca
 */
#include <stdlib.h>
#include <stdint.h>

void distorsion(int16_t*signal, int signalsize, float maxsignal);

