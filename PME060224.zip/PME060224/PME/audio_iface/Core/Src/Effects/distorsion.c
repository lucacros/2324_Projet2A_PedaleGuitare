#include "distorsion.h"

//distorsion effect
void distorsion(int16_t*signal, int signalsize, float maxsignal){
	for(int i=0; i < signalsize; i++){
		if(signal[i] > maxsignal){
			signal[i]= (int16_t)maxsignal;
		}
		else if(signal[i]<-maxsignal){
			signal[i]=(int16_t)(-maxsignal);
		}
	}
}

