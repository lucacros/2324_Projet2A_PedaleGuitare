/*
 * granular.h
 *
 *  Created on: Jan 16, 2024
 *      Author: Luca
 */

#include <stdlib.h>
#include <stdint.h>

// Size of the grains
//
#define GRAIN_SIZE 128

// Number of grains
#define NUM_GRAINS 2


//The Grain structure is created with three components:
//The content of the grain (audio data),
//The position of the grain in the overall audio signal,
//The size of the audio grain.

typedef struct {  //Grain representative structure
	int16_t* buffer;
	int position;
	int size;
} Grain;


void granular(int16_t* signal,int signalsize);

void initGrains();





