/*
 * potentiometer.h
 *
 *  Created on: Jan 16, 2024
 *      Author: Luca
 */


int PotentiometerValue(int potentiometerNumber);
