/*
 * gain.c
 *
 *  Created on: Feb 6, 2024
 *      Author: Luca
 */

#include "gain.h"

//gain
void gain(int16_t*signal, int signalsize, float gain){
	for(int i=0; i < signalsize; i++){
		float tmp = gain * (float)(signal[i]);
		signal[i]= (int16_t)(tmp);
	}
}


