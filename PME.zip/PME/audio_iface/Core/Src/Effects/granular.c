/*
 * granular.c
 *
 *  Created on: Jan 16, 2024
 *      Author: Luca
 */


#include "granular.h"

// Grain table
Grain grains[NUMS_GRAINS];

// Grain initialization
void initGrains() {
	for (int i=0; i<NUM_GRAINS; i++){
		grains[i].buffer =(int16_t*)malloc(GRAIN_SIZE * sizeof(int16_t));
		grains[i].position = rand()% GRAIN_SIZE;//position between 0 and GRAIN_SIZE - 1
		grains[i].size = GRAIN_SIZE;
	}
}


// Granular Effect
void granular(int16_t* signal, int signalsize) {
    for (int i = 0; i < signalsize; i++) {

        signal[i] = 0;

        for (int j = 0; j < NUM_GRAINS; j++) {
            int grainPosition = (i + grains[j].position) % grains[j].size; // Grain position in the buffer
            signal[i] += grains[j].buffer[grainPosition] / NUM_GRAINS; // Add to the overall signal

            // Update grain position
            grains[j].position++;
            grains[j].position %= grains[j].size;
        }
    }
}


