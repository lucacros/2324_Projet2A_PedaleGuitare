///*
// * delay.c
// *
// *  Created on: Jan 23, 2024
// *      Author: Luca
// */
//
//
//#include <stdint.h>
//#include <stdlib.h>
//#include <stdint.h>
//
////distorsion effect
//void delay(int16_t*signal, int signalsize,){
//	for(int i=0; i < signalsize; i++){
//		signal[i]= signal[i]
//	}
//}
//}
//
