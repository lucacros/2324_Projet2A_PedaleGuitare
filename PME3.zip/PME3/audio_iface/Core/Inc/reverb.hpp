// reverb.h
#include <stdint.h>

#ifndef  __mydsp_H__
#define  __mydsp_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif

#include <math.h>


#ifndef FAUSTCLASS
#define FAUSTCLASS mydsp
#endif

#ifdef __APPLE__
#define exp10f __exp10f
#define exp10 __exp10
#endif

#if defined(_WIN32)
#define RESTRICT __restrict
#else
#define RESTRICT __restrict__
#endif




void metadata(Meta* m) ;

int getNumInputs();

int getNumOutputs() ;

void classInit(int sample_rate);

void instanceConstants(int sample_rate);

void instanceResetUserInterface();

void instanceClear();

void init(int sample_rate);

void instanceInit(int sample_rate);

mydsp* clone();

int getSampleRate();

void buildUserInterface(UI* ui_interface);



void reverb(int count,FAUSTFLOAT** RESTRICT inputs,FAUSTFLOAT** RESTRICT outputs);




#endif
